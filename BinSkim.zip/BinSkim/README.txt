﻿NOTE:
   msdia140.dll and symsrv.dll are licensed under Microsoft 
   Windows Software Development Kit (SDK) for Windows 10:  
   https://dev.windows.com/en-US/downloads/windows-10-sdk
